/* Use of STL Container: Sequential contianer => E.g. std::vector */

/* In STL, the vector is a dynamic array that is capable of growing as needed
in order to contain its elements. Vectors allow random access to elements
(use of []); also and insertion and deletion of elements at the end is fast */


#include <iostream>
//Providing the std::vector container from the STL
#include <vector>

using namespace std;
int main(){
    
    //declaration of a vector of type float named myVector
    vector<float> myVector;
    float flt = 1.125;
    int index;
    //Let insert something in myVector: Insertion done with a loop
    while (flt < 20){
        myVector.push_back(flt); //inserted at end of array
        flt *= 2;
    }
    //Let output what we inserted in the deque: output with a loop
    while (index < myVector.size()){
        cout<<myVector[index] <<" | ";
        index++;
    }
    cout<<endl;
    //Let access the second element: Random access
    cout<<"The second element is: " <<myVector[1] <<endl;
    //Let delete the first element of myVector
    myVector.erase(myVector.begin());
    cout<<"After deletion of the first element of the vector\nthe second element becomes: " 
        <<myVector[1] <<endl;
    return 0;
}
//The output should give this
/* 1.125 | 2.25 | 4.5 | 9 | 18 | 
The second element is: 2.25
After deletion of the first element; 
the second element becomes: 4.5 */