/* Use of STL Iterators: Read & write iterator */

/* As mentined in the previous code (read only iterator), An iterator 
is an object that can traverse a container class without the user 
having to know how the container is implemented. */


#include <iostream>
//Providing the std::vector container from the STL
#include <vector>

using namespace std;
int main(){
    
    //declaration of a vector of type float named myVector
    vector<float> myVector;
    float flt = 1.125;
    //Let insert something in myVector: Insertion done with a loop
    while (flt < 20){
        myVector.push_back(flt); //inserted at end of array
        flt *= 2;
    }
    vector<float>::iterator iter; // declaration of a read-only iterator
    iter = myVector.begin(); // assignment of iter to the start of myVector
    
    //Let output the elements of the vector: iterating through the vector
    while (iter != myVector.end()){
        cout<<*iter <<" | "; //Dereferencing the iterator. Output what iter points to
        iter++; //movinng (iterating) to the next element (or adress of the element)
    }
    cout<<endl;
    
    //Let access the second element: Random access
    iter = myVector.begin() + 1;
    cout<<"The second element is: " <<*iter <<endl;
    //Assigning a new element to iter: write 12.25 to position "2"
    *iter = 12.25;
    cout<<"After writing the new value to iter;\nThe second element is: " <<*iter <<endl;
    return 0;
}
/* The output should give this:
1.125 | 2.25 | 4.5 | 9 | 18 | 
The second element is: 2.25
After writing the new value to iter;
The second element is: 12.25 */