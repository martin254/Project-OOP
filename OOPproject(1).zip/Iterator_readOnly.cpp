/* Use of STL Iterators: Read_only iterator */

/* In STL, An iterator is any object that, pointing to some element 
in a range of elements (such as a container), has the ability to iterate 
through the elements of that range using a set of operators. In other 
words, an Iterator is an object that can traverse a container class 
without the user having to know how the container is implemented. */

//In the below example, we're going to iterate through a vector


#include <iostream>
//Providing the std::vector container from the STL
#include <vector>

using namespace std;
int main(){
    
    //declaration of a vector of type float named myVector
    vector<float> myVector;
    float flt = 1.125;
    //Let insert something in myVector: Insertion done with a loop
    while (flt < 20){
        myVector.push_back(flt); //inserted at end of array
        flt *= 2;
    }
    vector<float>::const_iterator iter; // declaration of a read-only iterator
    iter = myVector.begin(); // assignment of iter to the start of myVector
    
    //Let output the elements of the vector: iterating through the vector
    while (iter != myVector.end()){
        cout<<*iter <<" | "; //Dereferencing the iterator. Output what iter points to
        iter++; //movinng (iterating) to the next element (or adress of the element)
    }
    cout<<endl;
    return 0;
}
/* The output should give this:
1.125 | 2.25 | 4.5 | 9 | 18 | */