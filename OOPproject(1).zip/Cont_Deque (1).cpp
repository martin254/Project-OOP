/* Use of STL Container: Sequential contianer => E.g. std::Deque */

/* Unlike a queue which is a collection whose elements are added at one end 
(rear) and removed at another end (front); a deque or double-ended queue, is 
a queue that supports element insertion and removal at both ends. 
Like a queue, a deque can be implemented by an array, a linked list,... 
In this code, we're going to implement the deque with a dynamic array */


#include <iostream>
//Providing the std::deque container from the STL
#include <deque>

using namespace std;
int main(){
    
    //declaration of a deque of type float named myDeque
    deque<float> myDeque;
    float flt = 1.125;
    int arrayIndex;
    //Let insert something in our deque: Insertion by a loop
    while (flt < 10){
        myDeque.push_front(flt); //flt is pushed at the front of the array
        flt *= 2;
        myDeque.push_back(flt); //(2*flt) is pushed at the back of the array
    }
    
    //Let output what we inserted in the deque: output with a loop
    cout<<"| ";
    while (arrayIndex < myDeque.size()){
        cout<<myDeque[arrayIndex] <<" | ";
        arrayIndex++;
    }
    return 0;
}
/* The output should give something like this
"| 9 | 4.5 | 2.25 | 1.125 | 2.25 | 4.5 | 9 | 18 |"
when we input flt a the front, 
we then input its double at the back */